#!/bin/bash
while :; do echo 'Hit CTRL+C'; sleep 1; done
